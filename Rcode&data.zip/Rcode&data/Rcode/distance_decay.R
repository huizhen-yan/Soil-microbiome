# 1. Calculate the geographic distance among sampling sites

setwd("/home/yanhuizhen/soil_plot/data_input")
library(geosphere)
library(readxl)

group=read_excel("metadata-all205.xlsx",sheet = 1)

xy <- group[, c("name1", "longitude", "latitude")]
xy <- as.data.frame(xy)
rownames(xy) <- xy$name1
xy$name1 <- NULL

dm <- distm(xy, fun = distVincentyEllipsoid)
rownames(dm) <- rownames(xy)
colnames(dm) <- rownames(xy)
dm = as.data.frame(dm)


# 2. Calculate Bray-Curtis dissimilarity
otu <- read.table("table_noUECM_rare33130.txt", header = TRUE,
                  row.names = 1, sep = "\t", skip = 1, comment.char = "")

library(vegan)
bc <- vegdist(t(otu), method = "bray")
bc_matrix <- as.data.frame(as.matrix(bc))
bc_matrixback <- bc_matrix

# Ensure sample order matches in geographic and Bray-Curtis matrices
all(rownames(dm) == rownames(bc_matrix))
all(colnames(dm) == colnames(bc_matrix))

dm_sort <- dm[rownames(bc_matrix), rownames(bc_matrix)]
dm_sort <- dm_sort[, colnames(bc_matrix)]

all(rownames(dm_sort) == rownames(bc_matrix))
all(colnames(dm_sort) == colnames(bc_matrix))

bcs=1-bc_matrix
bcs[!lower.tri(bcs)] <- NA
dm_sort[!lower.tri(dm_sort)] <- NA

library(tidyverse) 
bcs_long <- bcs %>%
  rownames_to_column("row") %>%
  pivot_longer(cols = -row, names_to = "col", values_to = "bcsimilarity_value") %>%
  filter(!is.na(bcsimilarity_value))

dm_sort_long <- dm_sort %>%
  rownames_to_column("row") %>%
  pivot_longer(cols = -row, names_to = "col", values_to = "dm_value") %>%
  filter(!is.na(dm_value))

# join
df <- left_join(bcs_long, dm_sort_long, by = c("row", "col"))






# 3. Distance-decay analysis

group_type <- group[, c("name1", "type")]

layer_a <- group_type[group_type$type == "A", c("name1", "type")]
a <- subset(df, row %in% layer_a$name1 & col %in% layer_a$name1)

layer_b <- group_type[group_type$type == "B", c("name1", "type")]
b <- subset(df, row %in% layer_b$name1 & col %in% layer_b$name1)

layer_c <- group_type[group_type$type == "C", c("name1", "type")]
c <- subset(df, row %in% layer_c$name1 & col %in% layer_c$name1)

dfcom <- rbind(
  cbind(df, layer = "all"),
  cbind(a, layer = "A"),
  cbind(b, layer = "B"),
  cbind(c, layer = "C")
)

dfcom$layer <- factor(dfcom$layer, levels = c("all", "A", "B", "C"))
dfcom$dm100km <- dfcom$dm_value / 100 


# Plot
library(ggplot2)

p1 <- ggplot(dfcom, aes(x = dm100km, y = bcsimilarity_value)) +
  geom_point(aes(colour = layer), size = 1, alpha = 0.95) +
  geom_smooth(method = "lm", aes(colour = layer), se = TRUE, linetype = "solid")

p2 <- p1 +
  scale_color_manual(values = c("all" = "grey30",
                                "A"   = "#c3d583",
                                "B"   = "#FFCCCC",
                                "C"   = "#cc9966")) +
  theme_bw() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.text = element_text(size = 12, colour = "black"),
        strip.text = element_text(size = 14)) +
  labs(x = "Geographic distance (100km)", y = "Bray-Curtis similarity")

p2
ggsave(p2, file = "decay-layer.pdf",
       width = 10, height = 7.5, units = "cm")


# Linear model fitting
make_model <- function(df) { lm(bcsimilarity_value ~ dm100km, df) }

library(plyr)
models <- dlply(dfcom, "layer", .fun = make_model)

summary(models$all)
summary(models$A)
summary(models$B)
summary(models$C)
