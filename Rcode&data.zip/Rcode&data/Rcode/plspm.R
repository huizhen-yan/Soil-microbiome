setwd("/home/yanhuizhen/soil_plot/data_input")
library(plspm)
data=read.csv("environment125_geo_aoa.csv",header = T,row.names = 1)
data=as.data.frame(data)
data$FAOApcoa1=-1*data$AOApcoa1
data$FMC=-1*data$MC
data$FDOC=-1*data$DOC
data$FpH=-1*data$pH
data$FAP=-1*data$AP

sapply(data, is.numeric)

path=read.table("path_matrix6.txt",row.names = 1)
path=as.matrix(path)
blocks=list(
  c("latitude"),
  c( "MAT", "MAP"),
  c("pH"),
  c("NO3","FAP"),
  c("AOAabun100","FAOApcoa1"),
  c("bntiPCo1"))


modes=rep("A",6)
plspm_result=plspm(data,path,blocks,modes=modes,boot.val = TRUE,br=1000)
plspm_result$unidim
plspm_result$outer_model
plspm_result$gof
plspm_result$inner_model
plspm_result$inner_summary

