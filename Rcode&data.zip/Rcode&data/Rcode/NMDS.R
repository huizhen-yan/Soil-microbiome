setwd("/home/yanhuizhen/soil_plot/data_input")
# input
otu <- read.table("table_noUECM_rare33130.txt", header = TRUE, 
                  row.names = 1, sep = "\t", skip = 1, comment.char = "")

library(readxl)
group=read_excel("metadata-all205.xlsx",sheet = 1)
group5=group[,c("name1","type","climate.type2","vegetationy","province","city")]

# NMDS
library(vegan)
nmds<-metaMDS(t(otu),distance = "bray")
nmds$stress
nmds.point <- data.frame(nmds$point)
nmdsall <- merge(group5, nmds.point, by.x = "name1", by.y = "row.names", 
                 all.y = TRUE,sort = FALSE)

nmdsall$vegetationy=factor(nmdsall$vegetationy,
                           levels = c("Maize","Vegetable","Oilseed rape",
                                      "Wheat","Rice","Other"))
nmdsall$type=factor(nmdsall$type,levels = c("A","B","C"))
nmdsall$climate.type2=factor(nmdsall$climate.type2,
                             levels = c("subtropical","temperate","high mountain"))

# Plot
library(ggplot2)
p1=ggplot(nmdsall,aes(x=MDS1,y=MDS2))+
  stat_ellipse(data=nmdsall, geom = "polygon",level=0.95,
               linetype = 1,linewidth=0.8,aes(fill=vegetationy), 
               alpha=0.2, show.legend = T)+
  scale_fill_manual(values = c("Maize"="#815b34",        "Vegetable"="#4a75a7",
                               "Oilseed rape"="#D7ACC5", "Wheat"="#FF9933",
                               "Rice"="#67a459",         "Other"="grey70"))+
  geom_point(aes(colour=vegetationy),size=3,alpha=0.7)+
  scale_color_manual(values = c("Maize"="#815b34",        "Vegetable"="#4a75a7",
                                "Oilseed rape"="#D7ACC5", "Wheat"="#FF9933",
                                "Rice"="#67a459",         "Other"="grey70"))+
  theme_bw()+theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
  theme(axis.text = element_text(colour="black"))+
  theme(axis.text = element_text(size = 12),strip.text = element_text(size = 16))+
  labs(x="NMDS1",y="NMDS2")+theme(legend.position = "right")
p1

ggsave("nmds-vegetationy.pdf", plot = p1, width = 6, height = 4)


# Test for differences
library(vegan)
group5=group[,c("name1","type","climate.type2","vegetationy","city","province"),drop=F]
group5 = as.data.frame(group5)
rownames(group5)=group5$name1
identical(colnames(otu), rownames(group5)) 

group5_reordered <- group5[colnames(otu), ]
identical(colnames(otu), rownames(group5_reordered))


adonis2_res=adonis2(vegdist(t(otu),method = "bray")~vegetationy * type * climate.type2,
                    data = group5_reordered,permutations = 999)
adonis2_res
