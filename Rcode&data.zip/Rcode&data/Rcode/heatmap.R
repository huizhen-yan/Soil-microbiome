setwd("/home/yanhuizhen/soil_plot/data_input")
library(ggplot2)
library(ggcor)
library(dplyr)

library(psych)
df=read.csv("environment125_geo_aoa.csv",row.names = 1)
env=df[,c(
  "pH", "TN", "NO3", "NH4", "DOC", "CN", "AK",  "AP",                          
  "MAT", "MAP", "MC",
  "latitude", "longitude"),drop=F]
envcor_r=corr.test(env,env,use = "pairwise", method = "spearman")$r
envcor_padj=corr.test(env,env,use = "pairwise", method = "spearman")$p.adj
envcor_r[envcor_padj >= 0.05] <- 0 


speci=df[,c("AOAabun100","g__Candidatus_Nitrososphaera", "g__Candidatus_Nitrosotalea",
            "g__Candidatus_Nitrocosmicus", "g__Nitrosarchaeum", "g__Candidatus_Nitrosotenuis")]

corre <- corr.test(env,speci,use = "pairwise", method = "spearman") 
library(reshape2)
specor_r=corre$r   
specor_r_long=melt(
  as.matrix(specor_r),          
  varnames = c("from", "to"),
  value.name = "value"
)

specor_padj=as.data.frame(corre$p.adj)
specor_padj_long=melt(
  as.matrix(specor_padj),         
  varnames = c("from", "to"),
  value.name = "value"
)

library(tidyr)
b <- merge(specor_r_long, specor_padj_long, 
           by = c("from", "to"), 
           all = FALSE)
names(b)
colnames(b)[colnames(b) == "value.x"] <- "spr"
colnames(b)[colnames(b) == "value.y"] <- "sppadj"

b=b[,c("to","from","spr","sppadj")] 
b_sub=b[b$sppadj < 0.05,]
summary(b_sub$spr)
b_sub$spr_interval <- cut(b_sub$spr, breaks = c(-Inf, -0.5,0,0.5,Inf),
                          labels=c("<-0.5","-0.5-0","0-0.5",">=0.5"))
unique(b_sub$spr_interval)

p1=quickcor(envcor_r,type="upper",show.diag=FALSE,cor.test=FALSE)+
  geom_circle2()+
  scale_fill_gradient2(
    low = "#339933",     
    mid = "white",     
    high = "orange",   
    midpoint = 0,
    na.value = "grey90",  
    name = "Correlation"
  )+
  anno_link(aes(color=spr_interval,size=spr_interval),data=b_sub,curvature=-0.1)+
  scale_size_manual(values = c(1,0.25,0.25,1))+
  scale_colour_manual(values = c("#58b5e9","#58b5e9","#fd7672","#fd7672"))+
  guides(size = guide_legend(title = "Spearman",override.aes = list(colour = "grey35"), order = 2),
         colour = guide_legend(title = "Spearman", override.aes = list(size = 3), order = 1),
         fill = guide_colorbar(title = "Spearman", order = 3))

p1
ggsave(p1, file="heatmap.pdf", width = 20, height = 20, units = "cm")

