setwd("/home/yanhuizhen/soil_plot/data_input")
otu <- read.table("table_noUECM_rare33130.txt", header = TRUE, 
                  row.names = 1, sep = "\t", skip = 1, comment.char = "")
otuback=otu

library(readxl)
group=read_excel("metadata-all205.xlsx",sheet = 1)
group5=group[,c("name1","type","climate.type2","vegetationy","longitude","latitude")]

env=read.csv("environment125_geo_group.csv",header = T)
rownames(env) = env$name

otu=t(otu)
dim(otu)
otu_sub = otu[env$name,]
dim(otu_sub)
otu_sub = otu_sub[,colSums(otu_sub) != 0]
dim(otu_sub)

rowSums(otu_sub)


library(vegan)
otua = otu_sub
bc=vegdist(otua,method = "bray")

# Normalize
nenv=env
nenv=nenv[,c("longitude","latitude", 
             "pH","TN", "NO3", "NH4", "AK",
             "DOC", "CN", "AP", "MAT",  "MAP",
             "MC")]
nenv=as.data.frame(nenv)
nenv=decostand(nenv, method = "normalize", MARGIN = 2) #1=row,2=col

vare.cap <- capscale(bc~.,nenv)
plot(vare.cap) 

vif.cca(vare.cap)
## Check variance inflation factor (VIF) for each predictor and sequentially remove predictors with VIF > 10

ef=envfit(vare.cap,nenv,permutations=999)
ef

# Plot

library(ggplot2)
p=summary(vare.cap)
sites=p$sites[,c(1,2)]             
sites=sites/100                  
biplot=p$biplot[,c(1,2)]
biplot=as.data.frame(biplot)


group5 = as.data.frame(group5)
rownames(group5) = group5$name1
groupa = group5[rownames(env),c("climate.type2", "vegetationy")]

identical(rownames(sites), rownames(groupa))

dbRDA=data.frame(sites,groupa)

dbRDA$vegetationy <- factor(dbRDA$vegetationy, 
                            levels = c("Maize","Vegetable","Oilseed rape",
                                       "Wheat","Rice","Other"))
dbRDA$climate.type2 <- factor(dbRDA$climate.type2, 
                              levels = c("subtropical",
                                         "temperate",
                                         "high mountain"))

p1=ggplot(dbRDA,aes(x=CAP1,y=CAP2,colour=vegetationy))+
  geom_point(aes(shape=climate.type2),size=2,alpha=1)+
  geom_segment(aes(x=0,y=0,xend=0.02*CAP1,yend=0.02*CAP2),
               arrow=arrow(length=unit(0.2,"cm")),
               colour="black",data= biplot)+
  scale_color_manual(values = c("Maize"="#815b34",        "Vegetable"="#4a75a7",
                                "Oilseed rape"="#D7ACC5", "Wheat"="#FF9933",
                                "Rice"="#67a459",         "Other"="grey70"))+
  theme_bw()+
  theme(panel.grid.major=element_blank(),
        panel.grid.minor=element_blank())+
  geom_hline(aes(yintercept=0),colour="grey50",
             linetype="dashed")+
  geom_vline(aes(xintercept=0),colour="grey50", linetype="dashed")+
  theme(legend.text = element_text(size = 12))+
  theme(axis.text=element_text(colour="black"))+
  xlab("CAP1 (16.27%)")+ylab("CAP2 (4.89%)")
p1

p$cont

ggsave("dbRDA-plot.pdf", plot = p1, width = 6, height = 4)
