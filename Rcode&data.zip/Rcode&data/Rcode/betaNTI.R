setwd("/home/yanhuizhen/soil_plot/data_input")
library(iCAMP)
library(picante)
dir()

save.wd=   "/home/yanhuizhen/soil_bnti"

if(!dir.exists(save.wd)){dir.create(save.wd)}

# 读取数据，跳过第一行，保留列名(样本名)
otu <- read.table("table_noUECM_rare33130.txt", header = TRUE, 
                  row.names = 1, sep = "\t", skip = 1, comment.char = "")
dim(otu)

tree=read.tree("sequences_rootedtree.nwk")

otu=t(otu)
phy_match=prune.sample(otu,tree)
Ntip(phy_match)

pd.big=pdist.big(tree = phy_match, wd=save.wd, nworker = 96)

qp2=qpen(comm=otu, pd=pd.big$pd.file, pd.big.wd=pd.big$pd.wd,
         pd.big.spname=pd.big$tip.label, tree=phy_match, project = "rare33130sam205",
         rand.time=1000, nworker=96, save.bNTIRC = TRUE)
