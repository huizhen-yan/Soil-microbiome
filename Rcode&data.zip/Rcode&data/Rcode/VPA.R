setwd("/home/yanhuizhen/soil_plot/data_input")

otu <- read.table("table_noUECM_rare33130.txt", header = TRUE, 
                  row.names = 1, sep = "\t", skip = 1, comment.char = "")
otuback=otu

env=read.csv("environment125_geo_group.csv",row.names = 1,header = T)

otu_sub = otu[,rownames(env)]
dim(otu_sub)
otu_sub = otu_sub[rowSums(otu_sub) != 0,]
dim(otu_sub)

otu125 = t(otu_sub)
identical(rownames(otu125), rownames(env)) 


# VPA
library(vegan)
names(env)

nenv=env
nenv = nenv[,c("longitude",  "latitude",
               "MAT", "MAP",
               "TN",  "pH", "NO3", "NH4", "AK", "DOC", "CN", "AP", "MC")]
nenv=as.data.frame(nenv)
nenv=decostand(nenv, method = "normalize", MARGIN = 2) #1=row,2=col

vpa<-varpart(otu125,
             ~ longitude + latitude,
             ~ MAT + MAP,
             ~ TN + pH + NO3 + NH4 + AK +
               DOC + CN + AP + MC,
             data = nenv,
             transfo = 'hel')
vpa
plot(vpa,bg=2:5)
plot(vpa,bg=2:5,digits = 4,
     Xnames=c("Geo", 
              'Climate',
              "Env"))

pdf('plot.pdf',width = 9, height = 9)

plot(vpa,bg=2:5,digits = 4,
     Xnames=c("Geo", 
              'Climate',
              "Env"))
dev.off()


# Significance test
geo = nenv[,c("longitude", "latitude"),drop=F]
cli = nenv[,c("MAT", "MAP"),drop=F]
env = nenv[,c("TN", "pH", "NO3", "NH4", "AK",
              "DOC", "CN", "AP", "MC"),drop=F]
otu125=as.data.frame(otu125)

ageo = rda(otu125, geo, cbind(cli,env))
anova(ageo)

acli = rda(otu125, cli, cbind(geo,env))
anova(acli)

aenv = rda(otu125, env, cbind(geo,cli))
anova(aenv)
