setwd("/home/yanhuizhen/soil_plot/data_input")
# input
adiv=read.csv("rare33130_adiv_multi.csv",row.names = 1,header = T)
library(readxl)
group=read_excel("metadata-A-forallsample205-sid.xlsx",sheet = 1)
group5=group[,c("name2","type","climate.type2","vegetationy","province","city")]

identical(rownames(adiv), rownames(group5)) 

# merge
library(tidyr)
b <- merge(group5, adiv, by.x = "name2", by.y = "row.names", 
           all.y = TRUE,sort = FALSE)
b=as.data.frame(b)
b$pielou_evenness=NULL
b$faith_pd=NULL 
library(dplyr)
b_long <- b %>%
  gather(key = "aindex", value = "value", -name2,-province, -city,
         -type,-climate.type2,-vegetationy)

c=b_long
unique(c$aindex)
c$aindex=factor(c$aindex,levels = c("observed_features",
                                    "shannon_entropy"))
c$vegetationy=factor(c$vegetationy,levels = c("Maize","Vegetable","Oilseed rape",
                                              "Wheat","Rice","Other"))
c$type=factor(c$type,levels = c("A","B","C"))
c$climate.type2=factor(c$climate.type2,
                       levels = c("subtropical","temperate","high mountain"))

library(ggplot2)
p<-ggplot(c,aes(x=vegetationy,y=value,fill=type))+
  geom_boxplot(width=0.7,lwd=0.1,outlier.size = 1,outlier.colour = "grey")

p1=p+
  facet_wrap(~aindex,scales = "free",nrow = 2)+
  scale_fill_manual(values = c("A" ="#c3d583" ,                                   
                               "B"  ="#FFCCCC"  ,                             
                               "C"  ="#cc9966"))+
  theme_bw()+theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
  theme(axis.text = element_text(size = 12),strip.text = element_text(size = 14))+
  theme(axis.text = element_text(colour="black"))+labs(x="",y="")+
  theme(legend.position = "bottom",
        legend.direction = "horizontal")

p1
ggsave(p1, file="adiv-boxplot.pdf", 
       width = 14, height = 20, units = "cm")


# Kruskal–Wallis non-parametric test
sub_df=b[b$vegetationy == "Other", ]
kruskal.test(sub_df$shannon_entropy ~ type, data = sub_df)


