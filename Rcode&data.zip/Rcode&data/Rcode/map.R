setwd("/home/yanhuizhen/soil_plot/data_input")
library(ggplot2)
library(sf)
china <- sf::read_sf("china.geojson")
nine_line <- sf::read_sf("line.shp")

library(ggspatial)
ggplot() + 
  geom_sf(data = china,fill="NA",size=1,color="black") + 
  geom_sf(data = nine_line) + 
  coord_sf(crs = "+proj=laea +lat_0=40 +lon_0=104")+
  annotation_scale(location = "bl") +
  # spatial-aware automagic north arrow
  annotation_north_arrow(location = "tl", which_north = "false",
                         style = north_arrow_fancy_orienteering)


station=read.csv("metadata-A-formap125.csv",header = T)
# Import station coordinates of this study
scatter_df_tro <- st_as_sf(station,coords = c("longitude", "latitude"),
                           crs = 4326)
# WGS84 geographic coordinate system, commonly used for global data

scatter_df_tro$vegetationy <- factor(scatter_df_tro$vegetationy, 
                                     levels = c("Maize", "Vegetable", 
                                                "Oilseed rape", "Wheat",
                                                "Rice","Other"))
scatter_df_tro$shape <- factor(scatter_df_tro$shape, 
                               levels = c("surface","multilayer"))
# Set the order

map1 <- ggplot() + 
  geom_sf(data = china,fill="NA",size=0.5,color="grey30") + 
  geom_sf(data = nine_line,size=0.5,color="grey50")+
  geom_sf(data = scatter_df_tro,aes(colour=vegetationy,shape=shape),
          size=3,alpha=0.95)+
  coord_sf(ylim = c(-2387082,1654989),crs="+proj=laea +lat_0=40 +lon_0=104")+
  # coord_sf() changes the map projection and causes stretching
  scale_color_manual(values = 
                       c("Maize"="#815b34",        "Vegetable"="#4a75a7",
                         "Oilseed rape"="#D7ACC5", "Wheat"="#FF9933",
                         "Rice"="#67a459",         "Other"="grey70"))+
  # Assign colors to different vegetation types
  scale_shape_manual(values = c("surface"=19,"multilayer"=17),
                     guide="none")+
  # Sampling station traits: circle = surface soil only, triangle = multiple depths
  # Disable shape legend
  annotation_scale(location = "bl",style="bar") +
  # Add scale bar
  annotation_north_arrow(location = "tl", which_north = "false",
                         style = north_arrow_fancy_orienteering)+
  # Add north arrow, fancy style
  guides(color = guide_legend(override.aes = list(size = 3),
                              title = "Vegetation",label.position = "right",
                              position = "bottom",ncol=6))+
  # Adjust legend: circle size, title, label position, legend position, number of columns
  theme(panel.background = element_rect(fill = NA),
        panel.grid.major = element_line(colour = "grey80",size=0.2),
        legend.key = element_rect(color = "white"),
        axis.text = element_text(colour="black"),
        legend.text = element_text(margin = margin(r=6)))
# Remove gray background, adjust grid line style, remove legend background
# Set axis text to black, adjust spacing between legend labels

map1

nine_map <- ggplot() +
  geom_sf(data = china,fill='NA') + 
  geom_sf(data = nine_line,color='gray70',size=1)+
  coord_sf(ylim = c(-4028017,-1477844),xlim = c(117131.4,2115095),
           crs="+proj=laea +lat_0=40 +lon_0=104")+
  # ylim and xlim adjust map extent
  theme(
    axis.text = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank(),
    panel.grid = element_blank(),
    panel.background = element_blank(),
    panel.border = element_rect(fill=NA,color="grey10",
                                linetype=1,linewidth = 1),
    plot.margin=unit(c(0,0,0,0),"mm"))

nine_map

library(cowplot)
gg_inset_map = ggdraw() +
  draw_plot(map1) +
  draw_plot(nine_map, x = 0.81, y = 0.12, width = 0.1, height = 0.3)
gg_inset_map

# Export the figure
ggsave("map-colored_by_vegetation.pdf", plot = gg_inset_map, width = 8, height = 6)
