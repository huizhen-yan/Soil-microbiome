setwd("/home/yanhuizhen/soil_plot/data_input")
abun=read.csv("phylum-ra-ave1%.csv",header = T,row.names = 1)
abun=abun*100
rowSums(abun)

library(readxl)
group=read_excel("metadata-all205.xlsx",sheet = 1)
group5=group[,c("name1","stationid2","type","climate.type2","vegetationy")]


library(tidyr)
b <- merge(group5, abun, by.x = "name1", by.y = "row.names", 
           all.y = TRUE,sort = FALSE)
b=as.data.frame(b)

library(dplyr)
b_long <- b %>%
  gather(key = "taxa", value = "value", -name1,-stationid2,
         -type,-climate.type2,-vegetationy)
c=b_long
unique(c$taxa)

library(ggplot2)
c$taxa=factor(c$taxa,levels = c(
  "Others",
  "Methylomirabilota",
  "Desulfobacterota",	
  "Firmicutes",
  "Nitrospirota",
  "Myxococcota",
  "Gemmatimonadota",
  "Verrucomicrobiota",
  "Actinobacteriota",
  "Planctomycetota",
  "Chloroflexi",
  "Bacteroidota",
  "Acidobacteriota",
  "Proteobacteria",
  
  "Crenarchaeota"))

c$stationid2=factor(c$stationid2,levels = c(
  "S1",
  "S2",
  "S3",
  "S4",
  "S5",
  "S6",
  "S7",
  "S9",
  "S10",
  "S11",
  "S12",
  "S13",
  "S14",
  "S15",
  "S16",
  "S17",
  "S18",
  "S19",
  "S20",
  "S21",
  "S22",
  "S23",
  "S24",
  "S25",
  "S26",
  "S27",
  "S28",
  "S29",
  "S30",
  "S31",
  "S32",
  "S33",
  "S34",
  "S35",
  "S36",
  "S37",
  "S38",
  "S39",
  "S41",
  "S42",
  "S43",
  "S44",
  "S45",
  "S46",
  "S47",
  "S48",
  "S49",
  "S50",
  "S51",
  "S52",
  "S53",
  "S54",
  "S55",
  "S56",
  "S57",
  "S58",
  "S59",
  "S60",
  "S61",
  "S62",
  "S63",
  "S65",
  "S68",
  "S69",
  "S70",
  "S71",
  "S72",
  "S73",
  "S74",
  "S75",
  "S76",
  "S77",
  "S78",
  "S79",
  "S80",
  "S81",
  "S82",
  "S83",
  "S84",
  "S85",
  "S86",
  "S87",
  "S88",
  "S89",
  "S90",
  "S91",
  "S92",
  "S93",
  "S94",
  "S95",
  "S96",
  "S97",
  "S98",
  "S99",
  "S100",
  "S101",
  "S102",
  "S103",
  "S104",
  "S105",
  "S106",
  "S107",
  "S108",
  "S109",
  "S110",
  "S111",
  "S112",
  "S113",
  "S114",
  "S115",
  "S116",
  "S117",
  "S118",
  "S119",
  "S120",
  "S121",
  "S122",
  "S123",
  "S124",
  "S125",
  "S126",
  "S127",
  "S128",
  "S131",
  "S133"))


c$vegetationy=factor(c$vegetationy,levels = 
                       c("Maize","Vegetable","Oilseed rape",
                         "Wheat","Rice","Other"))
p1=ggplot(c, aes(x = stationid2, y = value, fill = taxa)) +
  geom_bar(stat = "identity") + 
  labs(title = NULL, x = NULL, y = "Relative abundance (%)")

p2=p1+scale_y_continuous(expand = c(0, 0))+ 
  facet_grid(type ~ vegetationy,scales="free_x",space="free_x")+
  scale_fill_manual(values = c(
    "Others"="grey70",
    "Methylomirabilota" = "#FF0033",
    "Desulfobacterota" = "#b15928",
    "Firmicutes" = "#FF9900",
    "Nitrospirota" = "#b2df8a",
    "Myxococcota" =  "#006633",
    "Gemmatimonadota" = "#33CC33",
    "Verrucomicrobiota" = "#0000FF",
    "Actinobacteriota"= "#336699",
    "Planctomycetota"= "#99CCFF",
    "Chloroflexi"= "#8dd3c7",
    "Bacteroidota"= "#CCCCFF",
    "Acidobacteriota"= "#cab2d6",
    "Proteobacteria"= "#FF9999",
    
    "Crenarchaeota"="#FFFF24"))+
  theme_bw()+
  theme(axis.text.x = element_text(angle = 90,hjust = 1,size = 7),
        panel.background = element_blank(),
        panel.grid.minor = element_blank(), 
        panel.grid.major.x = element_blank(), 
        panel.grid.major.y = element_line(color = "grey", linewidth = 0.25),
        strip.text = element_text(color = "black", size = 12),
        axis.text = element_text(colour="black"),
        panel.spacing.x = unit(0.1, "lines"), 
        panel.spacing.y = unit(0.5, "lines"), 
        legend.position = "right")

p2
ggsave(p2, file="barplot1.pdf", width = 30, height = 17, units = "cm")



